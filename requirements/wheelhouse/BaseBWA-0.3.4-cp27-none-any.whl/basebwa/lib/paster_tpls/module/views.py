from blazeweb import appimportauto
from blazeweb.view import HtmlTemplatePage

class Index(HtmlTemplatePage):
    def default(self):
        pass
